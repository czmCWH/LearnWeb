<script setup lang="ts">
//
</script>

<template>
  <view class="cart">cart</view>
</template>

<style lang="scss">
//
</style>
