<script setup lang="ts">
//
</script>

<template>
  <view class="category">category</view>
</template>

<style lang="scss">
//
</style>
