//index.js
Page({
  data: {
    motto: 'Hello World',
  },
  onLoad: function () {
  }
})
