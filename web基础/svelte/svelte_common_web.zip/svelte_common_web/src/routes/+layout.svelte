<script>
	import './styles.css';
</script>


<slot />

<style>
:root {
  font-family: PingFangSC-Regular, PingFang SC, sans-serif;
  font-size: 20px;
  min-height: 100vh;
  -webkit-tap-highlight-color: transparent;
}
</style>
