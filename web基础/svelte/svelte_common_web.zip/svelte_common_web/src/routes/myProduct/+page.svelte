<script>

</script>
<main>
    <h1>我的商品1</h1>
</main>


<style lang="scss">
main {
    display: flex;
	flex-direction: column;
    height: 100vh;
    background-color: pink;
}
h1 {
    font-size: 1.2rem;
    margin-top: 10px;
    background-color: blue;
}
</style>