<script>
import { onMount } from 'svelte';
import svelte_logo from '@assets/svelte-welcome.png'


onMount(() => {
  console.log('App mounted');
});

</script>

<main>
	<h1>我是首页</h1>
	<img src={svelte_logo} />
</main>

<style lang="scss">
main {
	display: flex;
	flex-direction: column;
	height: 100vh;
	background-color: pink;
}
h1 {
	font-size: 2rem;
}
</style>
