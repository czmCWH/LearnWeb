<script>
  import { onMount } from "svelte";
  import task_icon from "@assets/task-icon.png";
  import member_icon from "@assets/member-item.png";

  let integral = 0;
  let usedIntegral = 0;
  let obtainDay = 0;

  const memberList = [
    {
      day: "1",
      member: 10,
    },
    {
      day: "7",
      member: 50,
    },
    {
      day: "15",
      member: 100,
    },
  ];

  const onSubmit = () => {
    console.log("去完成");
  };
</script>

<main>
  <div class="banner">
    <div class="banner-title">
      <span>{integral}</span> <span>积分</span>
    </div>
    <div class="banner-desc">
      已兑换 <span>{usedIntegral}</span> 积分，领了 <span>{obtainDay}</span> 天会员
    </div>
  </div>
  <h3>做任务赚积分</h3>
  <div class="task">
    <img class="task-icon" src={task_icon} />
    <span class="task-rule">
      <div>看视频 领积分</div>
      <div>观看视频可获得 <span>2</span> 积分</div>
    </span>
    <div class="task-btn" on:click={onSubmit}>去完成</div>
  </div>

  <h3>用积分兑会员</h3>

  <div class="member">
    {#each memberList as { day, member }, i}
      <div class="member-item">
        <img class="item-icon" src={member_icon} />
        <div class="item-desc"><span>{day}</span> 天会员</div>
        <div class="item-btn">{member} 积分兑换</div>
      </div>
    {/each}
  </div>
</main>

<style lang="scss">
  main {
    position: relative;
    padding: 0 1rem;
    min-height: 100vh;
    background-color: #333333;
    overflow: hidden;
  }

  .banner {
    position: relative;
    padding: 0.85rem;
    margin-top: 0.35rem;
    height: 5.3rem;
    background: url("@assets/feifei-ad-banner.png") no-repeat;
    background-size: 100% 100%;
  }

  .banner-title {
    span:first-child {
      font-size: 1.6rem;
      font-family: DINAlternate-Bold, DINAlternate;
      font-weight: bold;
      color: #ffffff;
    }
    span:last-child {
      font-size: 0.6rem;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: rgba(235, 235, 245, 0.6);
    }
  }

  .banner-desc {
    position: absolute;
    bottom: 0.85rem;
    font-size: 0.6rem;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: #ffffff;
    span {
      font-family: DINAlternate-Bold, DINAlternate;
      font-weight: 700;
      font-size: 0.8rem;
      color: #dcff00;
    }
  }
  h3 {
    margin: 1.15rem 0 0 0;
    font-size: 0.9rem;
    font-family: PingFangSC-Semibold, PingFang SC;
    font-weight: 600;
    color: #ffffff;
    line-height: 1.25rem;
    height: 1.25rem;
  }
  .task {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 0.4rem 0 0 0;
    padding: 0.75rem 0.8rem;
    border-radius: 18px;
    background: #242424;
  }
  .task-icon {
    width: 2rem;
    height: 2rem;
  }
  .task-rule {
    align-self: flex-start;
    flex: 1;
    margin-left: 0.5rem;

    div:first-child {
      font-size: 0.7rem;
      font-family: PingFangSC-Semibold, PingFang SC;
      font-weight: 600;
      color: #ffffff;
    }
    div:last-child {
      margin-top: 0.1rem;
      font-size: 0.55rem;
      color: rgba(235, 235, 245, 0.6);
      span {
        font-size: 0.65rem;
        font-family: DINAlternate-Bold, DINAlternate;
        color: #dcff00;
      }
    }
  }
  .task-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 5.05rem;
    height: 1.6rem;
    background: #dcff00;
    border-radius: 0.7rem;
    font-size: 0.6rem;
    font-family: PingFangSC-Semibold, PingFang SC;
    font-weight: 600;
    color: #333333;
  }
  .member {
    display: flex;
    flex-direction: column;
  }
  .member-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #242424;
    margin-top: 0.6rem;
    margin-bottom: 0.2rem;
    padding: 0.45rem 0.8rem;
    border-radius: 0.8rem;

    .item-icon {
      width: 1.6rem;
      height: 1.6rem;
    }
    .item-desc {
      flex: 1;
      font-size: 0.7rem;
      color: #ffffff;
      margin-left: 0.8rem;
      font-family: PingFangSC-Semibold, PingFang SC;
      font-weight: 400;
      span {
        font-size: 0.65rem;
        font-family: DINAlternate-Bold, DINAlternate;
        color: #dcff00;
        font-weight: 700;
      }
    }
    .item-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 5.05rem;
      height: 1.6rem;
      border-radius: 0.7rem;
      border: 1px solid #dcff00;
      font-size: 0.6rem;
      font-family: PingFangSC-Semibold, PingFang SC;
      font-weight: 600;
      color: #dcff00;
    }
  }
</style>
