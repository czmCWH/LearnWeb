/* empty css                   */const prerender = true;
const ssr = false;
export {
  prerender,
  ssr
};
