import { c as create_ssr_component } from "../../chunks/index.js";
/* empty css                   */const _layout_svelte_svelte_type_style_lang = "";
const css = {
  code: ":root{font-family:PingFangSC-Regular, PingFang SC, sans-serif;font-size:20px;min-height:100vh;-webkit-tap-highlight-color:transparent}",
  map: null
};
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `${slots.default ? slots.default({}) : ``}`;
});
export {
  Layout as default
};
