import { c as create_ssr_component } from "../../../chunks/index.js";
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: "main.svelte-1maqkni{display:flex;flex-direction:column;height:100vh;background-color:pink}h1.svelte-1maqkni{font-size:1.2rem;margin-top:10px;background-color:blue}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `<main class="svelte-1maqkni"><h1 class="svelte-1maqkni">我的商品1</h1>
</main>`;
});
export {
  Page as default
};
