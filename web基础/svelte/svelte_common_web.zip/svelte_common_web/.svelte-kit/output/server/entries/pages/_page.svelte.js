import { c as create_ssr_component, d as add_attribute } from "../../chunks/index.js";
const svelte_logo = "/_app/immutable/assets/svelte-welcome.6c300099.png";
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: "main.svelte-c1j8i6{display:flex;flex-direction:column;height:100vh;background-color:pink}h1.svelte-c1j8i6{font-size:2rem}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `<main class="svelte-c1j8i6"><h1 class="svelte-c1j8i6">我是首页</h1>
	<img${add_attribute("src", svelte_logo, 0)}>
</main>`;
});
export {
  Page as default
};
