

export const index = 1;
export const component = async () => (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/entry/error.svelte.9e21e4d7.js","_app/immutable/chunks/index.35a29703.js","_app/immutable/chunks/singletons.83fc467e.js"];
export const stylesheets = [];
export const fonts = [];
