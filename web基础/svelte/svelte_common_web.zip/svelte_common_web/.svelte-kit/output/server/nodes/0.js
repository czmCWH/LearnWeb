

export const index = 0;
export const component = async () => (await import('../entries/pages/_layout.svelte.js')).default;
export const imports = ["_app/immutable/entry/_layout.svelte.cd9ee824.js","_app/immutable/chunks/index.35a29703.js"];
export const stylesheets = ["_app/immutable/assets/_layout.98d7ff53.css","_app/immutable/assets/styles.61a36776.css"];
export const fonts = [];
