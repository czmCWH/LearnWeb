import * as universal from '../entries/pages/_page.js';

export const index = 2;
export const component = async () => (await import('../entries/pages/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/+page.js";
export const imports = ["_app/immutable/entry/_page.svelte.25f16576.js","_app/immutable/chunks/index.35a29703.js","_app/immutable/entry/_page.js.a193f9a8.js","_app/immutable/chunks/_page.f80f7fc2.js"];
export const stylesheets = ["_app/immutable/assets/_page.605cfd23.css","_app/immutable/assets/styles.61a36776.css"];
export const fonts = [];
