

export const index = 3;
export const component = async () => (await import('../entries/pages/myProduct/_page.svelte.js')).default;
export const imports = ["_app/immutable/entry/myProduct-page.svelte.8cfa9656.js","_app/immutable/chunks/index.35a29703.js"];
export const stylesheets = ["_app/immutable/assets/_page.794e954c.css"];
export const fonts = [];
