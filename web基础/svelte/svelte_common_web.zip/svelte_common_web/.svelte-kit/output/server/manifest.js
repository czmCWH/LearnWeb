export const manifest = {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png","robots.txt"]),
	mimeTypes: {".png":"image/png",".txt":"text/plain"},
	_: {
		client: {"start":{"file":"_app/immutable/entry/start.2d5b9a12.js","imports":["_app/immutable/entry/start.2d5b9a12.js","_app/immutable/chunks/index.35a29703.js","_app/immutable/chunks/singletons.83fc467e.js"],"stylesheets":[],"fonts":[]},"app":{"file":"_app/immutable/entry/app.9bdc274e.js","imports":["_app/immutable/entry/app.9bdc274e.js","_app/immutable/chunks/index.35a29703.js"],"stylesheets":[],"fonts":[]}},
		nodes: [
			() => import('./nodes/0.js'),
			() => import('./nodes/1.js'),
			() => import('./nodes/3.js')
		],
		routes: [
			{
				id: "/myProduct",
				pattern: /^\/myProduct\/?$/,
				params: [],
				page: { layouts: [0], errors: [1], leaf: 2 },
				endpoint: null
			}
		],
		matchers: async () => {
			
			return {  };
		}
	}
};
