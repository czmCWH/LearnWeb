import{default as t}from"../entry/_layout.svelte.cd9ee824.js";export{t as component};
