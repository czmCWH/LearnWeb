import{default as t}from"../entry/myProduct-page.svelte.8cfa9656.js";export{t as component};
