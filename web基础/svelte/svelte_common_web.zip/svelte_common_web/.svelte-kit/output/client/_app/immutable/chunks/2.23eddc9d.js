import{_ as r}from"./_page.f80f7fc2.js";import{default as t}from"../entry/_page.svelte.25f16576.js";export{t as component,r as universal};
