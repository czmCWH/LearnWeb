import{default as t}from"../entry/error.svelte.9e21e4d7.js";export{t as component};
