/* empty css               */const e=!0,r=!1,o=Object.freeze(Object.defineProperty({__proto__:null,prerender:e,ssr:r},Symbol.toStringTag,{value:"Module"}));export{o as _,e as p,r as s};
