/* empty css                       */import{p,s as o}from"../chunks/_page.f80f7fc2.js";export{p as prerender,o as ssr};
