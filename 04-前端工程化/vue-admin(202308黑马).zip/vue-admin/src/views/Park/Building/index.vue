<template>
  <div class="building-container">
    楼宇管理
  </div>
</template>

<script>

</script>

<style lang="scss" scoped>

</style>
