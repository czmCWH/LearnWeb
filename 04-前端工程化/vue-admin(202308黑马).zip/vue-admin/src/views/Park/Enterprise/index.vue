<template>
  <div class="enterprise-container">
    企业管理
  </div>
</template>

<script>
export default {
  name: 'Building'
}
</script>

<style lang="scss" scoped>
</style>
