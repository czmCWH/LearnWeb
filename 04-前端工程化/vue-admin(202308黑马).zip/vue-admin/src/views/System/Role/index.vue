<template>
  <div class="role-container">
    角色管理
  </div>
</template>

<script>

export default {
  name: 'Role'
}
</script>

<style scoped lang="scss">

</style>
