<template>
  <div class="employee-container">
    员工管理
  </div>
</template>

<script>
export default {
  name: 'Employee'
}
</script>

<style lang="scss" scoped>

</style>
