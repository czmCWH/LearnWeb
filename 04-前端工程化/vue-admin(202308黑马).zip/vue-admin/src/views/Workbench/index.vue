<script>

</script>

<template>
  <div class="databoard-container">
    工作台
  </div>
</template>

<style scoped lang="scss">

</style>
