<template>
  <div>一体杆管理</div>
</template>
