<template>
  <div>告警记录</div>
</template>
