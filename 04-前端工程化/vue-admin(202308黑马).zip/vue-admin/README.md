# vue-admin

> 基于vue-admin-template的二次定制脚手架，去掉了一些繁琐的东西，升级了一些包

**Live demo:** http://panjiachen.github.io/vue-admin-template


